import { Component, OnInit, ViewChild } from '@angular/core';
import { VehicledataService } from '../../Services/vehicledata.service';
import { Router } from '@angular/router';
import { IBrand } from 'src/app/Models/vehicle';
import { MatTableDataSource } from '@angular/material/table';
import { AlertService } from 'src/app/_alert';
import { FormControl } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { SelectionModel } from '@angular/cdk/collections';

@Component({
  selector: 'app-brands',
  templateUrl: './brands.component.html',
  styleUrls: ['./brands.component.css'],
})
export class BrandsComponent implements OnInit {
  brands: IBrand[]; 
  displayedColumns: string[] = ['name', 'shortDiscription', 'id'];

  dataSource: MatTableDataSource<IBrand>;
  selection: SelectionModel<IBrand>;

  // brandList: IBrand[];
  brandSearch = new FormControl();

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(
    private brandService: VehicledataService,
    private route: Router,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {

    this.alertService.clear();
    this.brandService.getAllBrands().subscribe((data: any) => {
      this.brands = data;
      
      this.dataSource = new MatTableDataSource(this.brands);

      this.selection = new SelectionModel(true, []);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;

    });
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  customApplyFilter(name: string) {
    this.dataSource.filter = name;
  }

  onEdit(id) {
    this.route.navigate(['/addbrand', id]);
  }

  onDelete(id) {
    this.brandService.deleteBrand(id).subscribe(
      (data) => {
        console.log(data);
        this.alertService.success('Brand Deleted!');
        location.reload();
      },
      (error) => {
        this.alertService.error(error.error);
      }
    );
  }
}
