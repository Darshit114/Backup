import { SelectionModel } from '@angular/cdk/collections';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { IBrand, IModel } from 'src/app/Models/vehicle';
import { VehicledataService } from 'src/app/Services/vehicledata.service';
import { AlertService } from 'src/app/_alert';

@Component({
  selector: 'app-model-details',
  templateUrl: './model-details.component.html',
  styleUrls: ['./model-details.component.css'],
})
export class ModelDetailsComponent implements OnInit {
  models: IModel[];
  displayedColumns: string[] = [ 'BrandId','name', 'modelYear','id'];

  aler:any;

  dataSource: MatTableDataSource<IModel>;
  selection: SelectionModel<IBrand>;

  brandSearch = new FormControl();

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  constructor(
    private modelService: VehicledataService,
    private route: Router,
    private alertService: AlertService,
  ) {
  }

  ngOnInit(): void {
    this.modelService.getAllModels().subscribe((data: any) => {
      this.models = data;
      
      this.dataSource = new MatTableDataSource(this.models);

      this.dataSource.sortingDataAccessor = (item, property) => {
        switch(property) {
          case 'BrandId': return item.brand.name;
          default: return item[property];
        }
      };

      this.dataSource.filterPredicate = (data, filter) => {

        const accumulator = (currentTerm, key) => {
          return key === 'brand' ? currentTerm + data.brand.name : currentTerm + data[key];
        };

        const dataStrObj = data.brand.name;
        const year = data.modelYear;
        const modelName = data.name;
        
        // const dataStr = Object.keys(data.name).reduce(accumulator, '').toLowerCase();

        const res = modelName + dataStrObj + year;

        console.log(res);

        // Transform the filter by converting it to lowercase and removing whitespace.
        const transformedFilter = filter.trim().toLowerCase();
        return res.indexOf(transformedFilter) !== -1;

      }

     
      this.selection = new SelectionModel(true, []);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;

    });
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  onEdit(id) {
    this.route.navigate(['/addmodel', id]);
  }

  onDelete(id) {
    this.modelService.deleteModel(id).subscribe(
      (data) => {
        console.log(data);
        this.alertService.success('Model Deleted!');
        location.reload();
      },
      (error) => {
        this.alertService.error(error.error);
      }
    );
  }
}
