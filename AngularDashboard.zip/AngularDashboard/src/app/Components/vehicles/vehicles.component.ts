import { SelectionModel } from '@angular/cdk/collections';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { IBrand, IVehicle } from 'src/app/Models/vehicle';
import { AlertService } from 'src/app/_alert';
import { VehicledataService } from '../../Services/vehicledata.service';

@Component({
  selector: 'app-vehicles',
  templateUrl: './vehicles.component.html',
  styleUrls: ['./vehicles.component.css'],
})
export class VehiclesComponent implements OnInit {
  vehicles: any[];

  displayedColumns: string[] = [
    
    'vINNum',
    'licencePlate',
    'salesPrice',
    'BrandId',
    'ModelId',
    'kilometers',
    'fuelType',
    'color',
    'id'
  ];
  dataSource: MatTableDataSource<IVehicle>;
  selection: SelectionModel<IVehicle>;

  name: any = null;

  nameList: string[] = [];
  names = new FormControl();

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(
    private vehicleServie: VehicledataService,
    private route: Router,
    private alertService: AlertService
  ) {}

  ngOnInit(): void {


    this.vehicleServie.getAllBrands().subscribe((data: any[])=>{
      data.forEach(element => {
        this.nameList.push(element.name)
      })
      
    })

    this.vehicleServie.getAllVehicles().subscribe((data: any) => {

      this.vehicles = data;
      
      this.dataSource = new MatTableDataSource(this.vehicles);

      this.dataSource.sortingDataAccessor = (item, property) => {
        switch(property) {
          case 'ModelId': return item.modelMaster.name;
          case 'BrandId': return item.modelMaster.brand.name;
          default: return item[property];
        }
      };

      this.dataSource.filterPredicate = (data, filter) => {

        const accumulator = (currentTerm, key) => {
          return key === 'modelMaster' ? currentTerm + data.modelMaster.name : currentTerm + data[key];
        };

        const dataStrObj = data.modelMaster.name + data.modelMaster.brand.name;
                   
       
        const dataStr = Object.keys(data).reduce(accumulator, '').toLowerCase();

        const res = dataStr + dataStrObj;

        // Transform the filter by converting it to lowercase and removing whitespace.
        const transformedFilter = filter.trim().toLowerCase();
        return res.indexOf(transformedFilter) !== -1;
      }

      this.selection = new SelectionModel(true, []);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;

    });
  }

  applyFilter(event: Event) {

    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase(); 
   
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  customApplyFilter(name: string) {
    this.dataSource.filter = name;
  }

  onEdit(id) {
    this.route.navigate(['/addvehicle', id]);
  }

  onDelete(id) {
    this.vehicleServie.deleteVehicle(id).subscribe(
      (data) => {
        console.log(data);
        this.alertService.success('Vehicle Deleted successfully!');
        location.reload();
      },
      (error) => {
        this.alertService.error("Something went wrong! Can not delete!");
      }
    );
  }
}
