export const environment = {
  production: true,
  vehicledata : 'https://vpic.nhtsa.dot.gov/api//vehicles/GetVehicleTypesForMake/mercedes?format=json',
  apiURL: 'http://localhost:8080/api',
};
